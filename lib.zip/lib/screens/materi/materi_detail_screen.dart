import 'package:flutter/material.dart';

import '../../core/models/chemistry_topic.dart';
import '../../utils/app_colors.dart';

import '../ar/ar_menu_screen.dart';
import '../molecule/molecule_screen.dart';
import '../quiz/quiz_screen.dart';

class MateriDetailScreen extends StatelessWidget {
  final ChemistryTopic topic;

  const MateriDetailScreen({
    super.key,
    required this.topic,
  });

  String getDescription() {
    switch (topic.title) {

      case "Ikatan Kimia":
        return "Ikatan kimia merupakan gaya tarik-menarik antar atom yang menyebabkan atom-atom bergabung membentuk molekul atau senyawa yang stabil.";

      case "Termokimia":
        return "Termokimia mempelajari perubahan energi panas yang terjadi selama reaksi kimia berlangsung.";

      case "Kalorimetri":
        return "Kalorimetri mempelajari cara mengukur jumlah kalor yang dilepas atau diserap suatu reaksi.";

      case "Laju Reaksi":
        return "Laju reaksi adalah kecepatan berlangsungnya suatu reaksi kimia yang dipengaruhi berbagai faktor.";

      case "Asam Basa":
        return "Asam basa mempelajari sifat larutan berdasarkan teori Arrhenius, Bronsted-Lowry, dan Lewis.";

      case "Hidrolisis":
        return "Hidrolisis merupakan reaksi ion garam dengan air yang menghasilkan sifat asam ataupun basa.";

      case "Hasil Kali Kelarutan":
        return "Konsep Ksp digunakan untuk menentukan kelarutan suatu senyawa ionik.";

      case "Kesetimbangan Kimia":
        return "Kesetimbangan kimia terjadi ketika laju reaksi maju sama dengan laju reaksi balik.";

      case "Sel Volta":
        return "Sel Volta menghasilkan energi listrik melalui reaksi redoks spontan.";

      case "Elektrolisis":
        return "Elektrolisis menggunakan energi listrik untuk menjalankan reaksi redoks yang tidak spontan.";

      case "Hidrokarbon":
        return "Hidrokarbon merupakan senyawa yang hanya tersusun dari atom karbon dan hidrogen.";

      case "Daur Ulang Polimer":
        return "Daur ulang polimer bertujuan mengurangi limbah plastik dengan memanfaatkan kembali material polimer.";

      default:
        return "Materi Kimia.";
    }
  }
    @override
  Widget build(BuildContext context) {

    return Scaffold(

      backgroundColor: AppColors.background,

      appBar: AppBar(

        backgroundColor: Colors.transparent,

        elevation: 0,

        iconTheme: const IconThemeData(
          color: Colors.white,
        ),

        title: Text(
          topic.title,
          style: const TextStyle(
            color: Colors.white,
          ),
        ),

      ),

      body: ListView(

        padding: const EdgeInsets.all(22),

        children: [

          CircleAvatar(

            radius: 45,

            backgroundColor:
                topic.color.withValues(alpha: .18),

            child: Icon(
              topic.icon,
              size: 45,
              color: topic.color,
            ),

          ),

          const SizedBox(height: 25),

          Text(

            topic.title,

            style: const TextStyle(

              color: Colors.white,

              fontSize: 28,

              fontWeight: FontWeight.bold,

            ),

          ),

          const SizedBox(height: 18),

          Text(

            getDescription(),

            style: TextStyle(

              color: Colors.white.withValues(alpha: .75),

              fontSize: 16,

              height: 1.7,

            ),

          ),

          const SizedBox(height: 35),
          const Text(

            "Menu Pembelajaran",

            style: TextStyle(

              color: Colors.white,

              fontSize: 20,

              fontWeight: FontWeight.bold,

            ),

          ),

          const SizedBox(height: 18),

          ElevatedButton.icon(

            icon: const Icon(Icons.science),

            label: const Text("Lihat Detail Molekul"),

            style: ElevatedButton.styleFrom(

              minimumSize: const Size.fromHeight(55),

            ),

            onPressed: () {

              Navigator.push(

                context,

                MaterialPageRoute(

                  builder: (_) => const MoleculeScreen(),

                ),

              );

            },

          ),

          const SizedBox(height: 15),

          ElevatedButton.icon(

            icon: const Icon(Icons.view_in_ar),

            label: const Text("Mulai Augmented Reality"),

            style: ElevatedButton.styleFrom(

              minimumSize: const Size.fromHeight(55),

            ),

            onPressed: () {

              Navigator.push(

                context,

                MaterialPageRoute(

                  builder: (_) => const ARMenuScreen(),

                ),

              );

            },

          ),

          const SizedBox(height: 15),

          ElevatedButton.icon(

            icon: const Icon(Icons.quiz),

            label: const Text("Kerjakan Quiz"),

            style: ElevatedButton.styleFrom(

              minimumSize: const Size.fromHeight(55),

            ),

            onPressed: () {

              Navigator.push(

                context,

                MaterialPageRoute(

                  builder: (_) => const QuizScreen(),

                ),

              );

            },

          ),

          const SizedBox(height: 30),

        ],

      ),

    );

  }

}