import 'package:flutter/material.dart';

class MoleculeScreen extends StatelessWidget {
  const MoleculeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Detail Molekul'),
      ),
      body: const Center(
        child: Text(
          'Halaman Detail Molekul\nComing Soon',
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}