import 'package:flutter/material.dart';

import '../../data/practicum/reaction_rate.dart';
import '../../widgets/tool_drawer.dart';
import '../../widgets/progress_header.dart';
import '../../widgets/assistant_bubble.dart';
import '../../widgets/bottom_toolbar.dart';
import '../../widgets/material_drawer.dart';
import '../../services/practicum_engine.dart';
import '../../models/placed_object.dart';

class PracticumScreen extends StatefulWidget {
  const PracticumScreen({super.key});

  @override
  State<PracticumScreen> createState() => _PracticumScreenState();
}

class _PracticumScreenState extends State<PracticumScreen> {

late PracticumEngine engine;

  bool showTools = false;

  bool showMaterials = false;

  bool stepCompleted = false;
  final List<PlacedObject> placedObjects = [];

  String? assistantMessage;

  final practicum = reactionRatePracticum;

  @override
  void initState() {

    super.initState();

    engine = PracticumEngine(practicum);

  }
  @override
  Widget build(BuildContext context) {

    final step = engine.current;

    return Scaffold(

      backgroundColor: Colors.black,

      body: SafeArea(

        child: Stack(

          children: [

            /// ============================
            /// CAMERA PLACEHOLDER
            /// ============================

Positioned.fill(

  child: ARWorkspace(

    objects: placedObjects,

    onAccept: (object){

      setState((){

        placedObjects.add(object);

      });

    },

    child: Container(

      color: Colors.black,

      child: Column(

        mainAxisAlignment: MainAxisAlignment.center,

        children: [

          Icon(
            Icons.camera_alt_outlined,
            color: Colors.white24,
            size: 120,
          ),

          const SizedBox(height: 20),

          const Text(

            "AR Camera",

            style: TextStyle(

              color: Colors.white38,

              fontSize: 22,

              fontWeight: FontWeight.bold,

            ),

          ),

        ],

      ),

    ),

  ),

),

// progres holder
            Positioned(
              top: 0,
              left: 0,
              right: 0,
              child: ProgressHeader(
                title: practicum.title,
                currentStep: engine.currentStep + 1,
                totalStep: practicum.steps.length,
                onBack: () {
                  Navigator.pop(context);
                },
              ),
            ),
            /// ============================
            /// HEADER
            /// ============================

            Positioned(

              left: 0,

              right: 0,

              bottom: 0,

              child: BottomToolbar(

              canNext: stepCompleted,

                onTool: () {

                  setState(() {

                    showTools = !showTools;

                    showMaterials = false;

                  });

                },

                onMaterial: () {

                  setState(() {

                    showMaterials = !showMaterials;

                    showTools = false;

                  });

                },

                onData: () {

                },

                onHint: () {

                },

                onNext: () {

                  if(engine.next()){

                    setState((){

                      stepCompleted = false;

                    });

                  }else{

                    ScaffoldMessenger.of(context).showSnackBar(

                      const SnackBar(

                        content: Text(
                          "🎉 Praktikum selesai",
                        ),

                      ),

                    );

                  }

                },

              ),

            ),

            Positioned(

              right: 20,

              top: 110,

              child: AssistantBubble(

              title: assistantMessage ?? step.title,

              instruction: assistantMessage ?? step.instruction,

              hint: step.hint,

              ),

            ),

            ToolDrawer(
              visible: showTools,
              tools: practicum.tools,
              onSelected: (tool) {

                if (engine.validate(tool.id)) {

                  setState(() {
                    stepCompleted = true;

                    showTools = false;
                     assistantMessage =
      "✅ ${tool.name} berhasil digunakan.\nTekan Next untuk melanjutkan.";
                  });

                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      backgroundColor: Colors.green,
                      content: Text(
                        "✅ ${tool.name} berhasil digunakan",
                      ),
                    ),
                  );

                } else {

                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      backgroundColor: Colors.red,
                      content: Text(
                        "❌ Alat tidak sesuai",
                      ),
                    ),
                  );

                }

              },
            ),

            MaterialDrawer(
              visible: showMaterials,
              materials: practicum.materials,
              onSelected: (material){

                if(engine.validate(material.id)){

                setState(() {
                    stepCompleted = true;
                    showTools = false;
                });

                  ScaffoldMessenger.of(context).showSnackBar(

                    SnackBar(
                      backgroundColor: Colors.green,
                      content: Text(
                        "✅ ${material.name} benar",
                      ),

                    ),

                  );

                }else{

                  ScaffoldMessenger.of(context).showSnackBar(

                    SnackBar(
                      backgroundColor: Colors.red,
                      content: Text(
                        "❌ Bahan belum sesuai",
                      ),

                    ),

                  );

                }

              },
            ),

          ],
        ),
      ),
    );
  }

}