import 'package:flutter/material.dart';

class PlacedObject {

  final String id;
  final String name;

  Offset position;

  final bool isTool;

  PlacedObject({
    required this.id,
    required this.name,
    required this.position,
    required this.isTool,
  });

}