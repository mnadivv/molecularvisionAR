import 'package:flutter/material.dart';

import '../models/placed_object.dart';

class DraggableToolCard extends StatelessWidget {

  final String id;
  final String name;
  final bool isTool;

  const DraggableToolCard({
    super.key,
    required this.id,
    required this.name,
    required this.isTool,
  });

  @override
  Widget build(BuildContext context) {

    final card = Container(

      margin: const EdgeInsets.symmetric(
        horizontal: 16,
        vertical: 8,
      ),

      padding: const EdgeInsets.all(14),

      decoration: BoxDecoration(

        color: Colors.white,

        borderRadius: BorderRadius.circular(16),

        boxShadow: const [

          BoxShadow(
            color: Colors.black12,
            blurRadius: 8,
          )

        ],

      ),

      child: Row(

        children: [

          CircleAvatar(

            backgroundColor:
                isTool ? Colors.blue : Colors.orange,

            child: Icon(

              isTool
                  ? Icons.handyman
                  : Icons.science,

              color: Colors.white,

            ),

          ),

          const SizedBox(width: 15),

          Expanded(

            child: Text(

              name,

              style: const TextStyle(

                fontWeight: FontWeight.bold,

                fontSize: 16,

              ),

            ),

          ),

          const Icon(Icons.open_with),

        ],

      ),

    );

    return LongPressDraggable<PlacedObject>(

      data: PlacedObject(

        id: id,

        name: name,

        position: Offset.zero,

        isTool: isTool,

      ),

      feedback: Material(

        color: Colors.transparent,

        child: SizedBox(

          width: 220,

          child: card,

        ),

      ),

      childWhenDragging: Opacity(

        opacity: .35,

        child: card,

      ),

      child: card,

    );

  }

}