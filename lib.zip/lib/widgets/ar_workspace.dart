import 'package:flutter/material.dart';

import '../models/placed_object.dart';

class ARWorkspace extends StatelessWidget {

  final List<PlacedObject> objects;

  final Widget child;

  final Function(PlacedObject object) onAccept;

  const ARWorkspace({

    super.key,

    required this.objects,

    required this.child,

    required this.onAccept,

  });

  @override
  Widget build(BuildContext context) {

    return DragTarget<PlacedObject>(

      onAcceptWithDetails: (details) {

        final object = details.data;

        object.position = details.offset;

        onAccept(object);

      },

      builder: (context, candidate, rejected) {

        return Stack(

          children: [

            child,

            ...objects.map(

              (object) => Positioned(

                left: object.position.dx,

                top: object.position.dy,

                child: Container(

                  padding: const EdgeInsets.symmetric(
                    horizontal: 14,
                    vertical: 10,
                  ),

                  decoration: BoxDecoration(

                    color: object.isTool
                        ? Colors.blue.shade700
                        : Colors.orange.shade700,

                    borderRadius: BorderRadius.circular(14),

                    boxShadow: const [

                      BoxShadow(

                        color: Colors.black26,

                        blurRadius: 8,

                      ),

                    ],

                  ),

                  child: Row(

                    mainAxisSize: MainAxisSize.min,

                    children: [

                      Icon(

                        object.isTool
                            ? Icons.handyman
                            : Icons.science,

                        color: Colors.white,

                        size: 18,

                      ),

                      const SizedBox(width: 8),

                      Text(

                        object.name,

                        style: const TextStyle(

                          color: Colors.white,

                          fontWeight: FontWeight.bold,

                        ),

                      ),

                    ],

                  ),

                ),

              ),

            ),

          ],

        );

      },

    );

  }

}