import '../models/practicum.dart';

class PracticumEngine {

  final Practicum practicum;

  int currentStep = 0;

  PracticumEngine(this.practicum);

  bool get isFinished =>
      currentStep >= practicum.steps.length;

  get current =>
      practicum.steps[currentStep];

  bool validate(String itemId){

    if(isFinished){
      return false;
    }

    return current.requiredItemId == itemId;

  }

  bool next(){

    if(currentStep < practicum.steps.length - 1){

      currentStep++;

      return true;

    }

    return false;

  }

  void reset(){

    currentStep = 0;

  }

}